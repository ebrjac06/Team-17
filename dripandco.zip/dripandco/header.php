
<?php include 'header.php';?>

<!DOCTYPE html>
<html>
<header>
  <div class="logo"><a href="Home Page.html"><img src="DRIP & CO LOGO.png" style="width:100px;height:70px;"></a></div>
  <div class="search-box">
    <input type="text" placeholder="Search">
  </div>
 <div class="icons">
  <a href="">
    <img src="https://media.istockphoto.com/id/1433268430/vector/favorite-icon.jpg?s=612x612&w=0&k=20&c=an0bIbEd-o5B4Lhc1i-alApeUnFopvIoiyIQFwKcCgs=" style="width: 35px; height: 35px;">
  </a>

  <a href="Basket Page.html">
    <img src="https://media.istockphoto.com/id/2206624277/vector/picnic-basket-vector-icon-design-illustration.jpg?s=612x612&w=0&k=20&c=YDUdNaBUc2UTJ0NNJidVQ-aBFZANsU_FsLue7fnm4Mo=" style="width: 25px; height: 25px;">
  </a>

  <a href="Signup.html">
    <img src="https://media.istockphoto.com/id/1317551894/vector/account-avatar-member-person-profle-user-icon-eps-vector.jpg?s=612x612&w=0&k=20&c=5YcHVMGR1ur6uZ_t3uAjKZoapyFuaN1eWFYcHFseEPM=" style="width: 35px; height: 35px;">
  </a>
</div>

</header>
<nav> <a href="Mens page.html">Mens</a> <a href="Womens Page.html">Womens</a> <a href="Contact us.html">Contact Us</a> <a href="About us.html">About Us</a> </nav>




